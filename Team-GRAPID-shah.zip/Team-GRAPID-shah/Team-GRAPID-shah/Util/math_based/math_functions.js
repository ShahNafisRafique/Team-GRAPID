 //Converts degrees to radians and returns it
 //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ check for invalid input
function degToRad(degrees) {
	return degrees * Math.PI / 180;
}